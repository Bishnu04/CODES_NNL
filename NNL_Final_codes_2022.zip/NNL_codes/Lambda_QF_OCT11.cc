// Oct 11, 2021
// Author Bishnu Pandey
// Fitting the SIMA simulated Lambda QF distribution
/// The code is /Desktop/May_2021/OCTOBER_1$ emacs Fit_Lambda_okuyama.C

double FMM_Response( double *x, double *par ){
  double invsq2pi = 0.3989422804014;   // (2 pi)^(-1/2)
  double mpshift  = -0.2278298;///-0.22278298       // Landau maximum location
  double np = 500.0;      // number of convolution steps
  double sc =   5; //5.0// convolution extends to +-sc Gaussian sigmas
  double xx, mpc, fland, sum = 0.0, xlow,xupp, step, i;
  double val1, val2;
  
  // MP shift correction
  mpc = par[1] - mpshift * par[0];/// original

  // Range of convolution integral
  xlow = x[0] - sc * par[3];
  xupp = x[0] + sc * par[3];
  step = (xupp-xlow) / np;
  // Convolution integral of Landau and Gaussian by sum
  for(i=1.0; i<=np/2; i++) {
    xx = xlow + (i-0.5) * step;////
    fland = TMath::Landau(xx,mpc,par[0]) / par[0];
    sum += fland * TMath::Gaus(x[0],xx,par[3]);
    
    xx = xupp - (i-.5) * step;
    fland = TMath::Landau(xx,mpc,par[0]) / par[0];
    sum += fland * TMath::Gaus(x[0],xx,par[3]);
  }
  val1 = step * sum * invsq2pi / par[3]; /// original
 
  /*------Landau * Gauss convluted------*/
  
  // Range of convolution integral
  sum  = 0.;
  xlow = 0.;
  xupp = x[0] + 1.6 * sc * par[3];///xupp = x[0] + 1.6 * sc * par[3];
  step = (xupp-xlow) / np;
  if(step<0.)step = 0.;
  // Convolution integral
  for(i=1.0; i<=np/2; i++){
    xx = xlow + (i-0.5) * step - par[5];
    fland = TMath::Gaus(xx,x[0],par[3]);
    sum += fland * TMath::Exp(-xx/par[4]);
    xx = xupp - (i-.5) * step - par[5];
    fland = TMath::Gaus(xx,x[0],par[3]);
    sum += fland * TMath::Exp(-xx/par[4]);
  }
  //val = par[2] * step * sum * invsq2pi / par[3];
  val2 =  step * sum * invsq2pi / (par[3]*par[4]*exp(par[5]/par[4]));
 // val2 =  step * sum * invsq2pi / (par[3]*par[4]);
  /*------Exp * Gauss convluted------*/
  // return par[2]*(val1+par[6]*val2)/(1.+par[6]);//N x (Landau*Gauss) + N' x (Exp*Gauss)//// original
  return par[2]*(val1+par[6])*1.0;///BP changed from last line to this line oct 12, 2021
 

  
}/// end of FMM_Response

 // FUNCTION PARAMETER
//par[0]=Width (scale) parameter of Landau density
//par[1]=Most Probable (MP, location) parameter of Landau density
//par[2]=Total area (integral -inf to inf, normalization constant)
//par[3]=Width (sigma) of convoluted Gaussian function
//par[4]=tau of exp function
//par[5]=Shift of Function Peak
//par[6]=Relative Strength



void Lambda_QF_OCT11()
{
  gStyle->SetOptStat(0);
  gStyle->SetOptFit(1111111);
  
  gStyle->SetStatFont(62);
  gStyle->SetStatFontSize(0.05);
  gStyle->SetStatTextColor(2);
  
  gStyle->SetPadRightMargin(0.08);
  gStyle->SetPadLeftMargin(0.14);
  gStyle->SetPadTopMargin(0.04);
  gStyle->SetPadBottomMargin(0.165);
  
  double fit_min = -4;
  double fit_max = 154;
  TF1* f = new TF1( "FMM_Response", FMM_Response, fit_min,fit_max, 7);
  
  
  TFile *t3 = new TFile("./root/SIMA_Lambda_QF_OCT_11.root");
  TH1F *h3 = (TH1F*)t3->Get("h1"); ///C/1.5 MeV

  /// original parameters from Kazuki
  // f->SetParameter(0,2.7e1);///2.7e0/// BP changed from  2.7e0 to 2.7e1
  // f->SetParameter(1, 4.9e1);///4.4e1
  // //f->SetParLimits(1, 4.7e1,4.9e1);///4.4e1  
  // f->SetParameter(2, 9.6e+2);// 9.6e+2
  // f->SetParameter(3, 4.1e0);//4.1e0
  // f->SetParameter(4,1.e11);//1.0e11
  // f->SetParameter(5, 3.3e4);//3.3e4
  // f->SetParameter(6, 1.4e-1); //1.4e-1
  // f->SetNpx(10000);
  

  f->SetParameter(0,1.40334e+01);///2.7e0 //1.40334e+01
  f->SetParameter(1, 4.13433e+01);///4.4e1 //4.13433e+01
  //f->SetParLimits(1, 4.7e1,4.9e1);///4.4e1 // 
  f->SetParameter(2, 2.56285e+06);// 9.6e+2 //2.56285e+06
  f->SetParameter(3, 2.24051e+01);//4.1e0 // 2.24051e+01
  f->SetParameter(4,1.00000e+11);//1.0e11 ///1.00000e+11
  f->SetParameter(5, 3.30000e+04);//3.3e4 // 3.30000e+04
  f->SetParameter(6, -1.20610e-03); //1.4e-1 // -1.20610e-03
  f->SetNpx(10000);
  
  TCanvas *c3 = new TCanvas("c3","c3",600,600);
  c3->cd();
  h3->Draw();
  
  h3->Fit(f, "EM", "", -4, 154.0);
  
  TLatex l3;
  l3.SetTextSize(0.04);  
  l3.DrawLatex(-80,15000, Form("#Lambda QF ditribution (SIM A)"));
}
// TLatex l3;
//   l3.SetTextSize(0.04);  

//   l3.DrawLatex(-80,15000, Form("#Lambda QF ditribution"));
//   l3.DrawLatex(-80,13500, Form("Fitted up to 9^{th} order Pol."));
//   l3.DrawLatex(-80,12000, Form("(4^{th} order not included)."));
  
//   l3.DrawLatex(-80,10000, Form("#chi^{2}/NDF = %.4g",f1->GetChisquare()/f1->GetNDF()));
