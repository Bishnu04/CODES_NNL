
void SIGMA_QF_OCT13(){
  gStyle->SetOptFit(1111);
  gStyle->SetStatFont(62);
  gStyle->SetStatFontSize(0.05);
  gStyle->SetStatTextColor(2);
  
  gStyle->SetPadRightMargin(0.08);
  gStyle->SetPadLeftMargin(0.14);
  gStyle->SetPadTopMargin(0.04);
  gStyle->SetPadBottomMargin(0.165);
  
  TFile *t4 = new TFile("./root/SIMA_Lambda_QF_OCT_11.root");
  TH1F *h4 = (TH1F*)t4->Get("h1"); ///C/1.5 MeV
  
  TFile *t3 = new TFile("./root/SIMA_3He_contamination_OCT_11.root");
  TH1F *h3 = (TH1F*)t3->Get("h1"); ///C/1.5 MeV

  TFile *t5 = new TFile("./root/SIMA_Sigma_QF_OCT_11.root");
  TH1F *h5 = (TH1F*)t5->Get("h1"); ///C/1.5 MeV

  
  TF1 *f1 = new TF1("f1","[0]+[1]*x+[2]*pow(x,2)",73.5,98.);  
  f1->FixParameter(0,5.57614e+00);///73.5,98 2nd order fit parameters 
  f1->FixParameter(1,-4.99964e+02);
  f1->FixParameter(2,6.87242e+00);
  
  /// This fun is used to fit Oct 13, 10 pm 2021
  TF1 *f3 = new TF1("f3","gaus(0)+f1 ",73.,153.5);//ranges used (73.5,156.6) and (73.5,153.5)
  f3->SetParameter(0,2.94066e+04);/// Gaus parameters
  f3->SetParameter(1, 1.22014e+02);
  f3->SetParameter(2, 2.19876e+01);///2.19876e+01  

  f3->FixParameter(3,-3.84497e+04);/// 2nd timefitted par//-3.84497e+04
  f3->FixParameter(4,7.45840e+02);//7.45840e+02
  f3->FixParameter(5, -3.82731e+00);//-3.82731e+00)   
  f3->SetNpx(1000);  
 
  
  
  TF1 *f5 = new TF1("f5","[0]+[1]*x+[2]*pow(x,2)+[3]*pow(x,3)+[4]*pow(x,4)+[5]*pow(x,5)+[6]*pow(x,6)",73.,155.); 
  f5->FixParameter(0,-2.92745e+05);///// par from 73, 160
  f5->FixParameter(1,1.33525e+04);
  f5->FixParameter(2, -2.21779e+02);
  f5->FixParameter(3,1.17716e+00);
  f5->FixParameter(4,6.79397e-03);
  f5->FixParameter(5, -9.03715e-05);
  f5->FixParameter(6, 2.40686e-07);  
  f5->SetNpx(1000);  

  TF1 *f6 = new TF1("f6","gaus(0)+[3]+[4]*x+[5]*pow(x,2)+[6]*pow(x,3)+[7]*pow(x,4)+[8]*pow(x,5)+[9]*pow(x,6)",72.95,164.32); 
  f6->SetParameter(0,2.94066e+04);/// Gaus parameters
  f6->SetParameter(1, 1.22014e+02);
  f6->SetParameter(2, 2.19876e+01);///2.19876e+01

   
  f6->FixParameter(3,-2.92745e+05);// par from 73, 160
  f6->FixParameter(4,1.33525e+04);
  f6->FixParameter(5, -2.21779e+02);
  f6->FixParameter(6,1.17716e+00);
  f6->FixParameter(7,6.79397e-03);
  f6->FixParameter(8, -9.03715e-05);
  f6->FixParameter(9, 2.40686e-07);
  f6->SetNpx(1000); 
  

  // f6->SetParameter(3,-2.92745e+05);// par from 73, 160
  // f6->SetParameter(4,1.33525e+04);
  // f6->SetParameter(5, -2.21779e+02);
  // f6->SetParameter(6,1.17716e+00);
  // f6->SetParameter(7,6.79397e-03);
  // f6->SetParameter(8, -9.03715e-05);
  // f6->SetParameter(9, 2.40686e-07);
  // f6->SetNpx(1000);  
  
  
  TCanvas *c1 = new TCanvas("c1","c1",600,600);
  c1->cd();
  h5->Draw();
  h5->Fit("f6","MR+");
  
  TLatex l3;
  l3.SetTextSize(0.04);  
  l3.DrawLatex(20,25000, Form("#Sigma QF ditribution (SIM A)"));
 
}



