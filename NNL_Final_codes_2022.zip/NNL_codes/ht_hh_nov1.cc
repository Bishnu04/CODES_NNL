double FMM_Response( double *x, double *par ){//copied from result_2D.C (2020/12/21)

  double invsq2pi = 0.3989422804014;   // (2 pi)^(-1/2)
  double mpshift  = -0.22278298;       // Landau maximum location
  double np = 500.0;      // number of convolution steps
  double sc =   5.0;      // convolution extends to +-sc Gaussian sigmas
  double xx, mpc, fland, sum = 0.0, xlow,xupp, step, i;
  double val1, val2;

  // MP shift correction
  mpc = par[1] - mpshift * par[0];
  // Range of convolution integral
  xlow = x[0] - sc * par[3];
  xupp = x[0] + sc * par[3];
  step = (xupp-xlow) / np;
  // Convolution integral of Landau and Gaussian by sum
  for(i=1.0; i<=np/2; i++) {
	xx = xlow + (i-.5) * step;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);

	xx = xupp - (i-.5) * step;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);
  }
  val1 = step * sum * invsq2pi / par[3];

  /*------Landau * Gauss convluted------*/

  // Range of convolution integral
  sum  = 0.;
  xlow = 0.;
  xupp = x[0] + 1.6 * sc * par[3];
  step = (xupp-xlow) / np;
  if(step<0.)step = 0.;
  // Convolution integral
  for(i=1.0; i<=np/2; i++){
	xx = xlow + (i-0.5) * step - par[5];
	fland = TMath::Gaus(xx,x[0],par[3]);
	sum += fland * TMath::Exp(-xx/par[4]);
	xx = xupp - (i-.5) * step - par[5];
	fland = TMath::Gaus(xx,x[0],par[3]);
	sum += fland * TMath::Exp(-xx/par[4]);
  }
 
  val2 =  step * sum * invsq2pi / (par[3]*par[4]*exp(par[5]/par[4]));
 

  return par[2]*(val1+par[6]*val2)/(1.+par[6]);//N x (Landau*Gauss) + N' x (Exp*Gauss)

}/// end of FMM_Response

////////------------------------------------------------------------------------------------------------------------------------

void ht_hh_nov1(){ 
 // gROOT->Reset();
  gStyle->SetOptStat(0);
  gStyle->SetOptFit(0);
  
  gStyle->SetOptStat(0);
  gStyle->SetPadRightMargin(0.06);
  gStyle->SetPadLeftMargin(0.18);
  gStyle->SetPadTopMargin(0.05);
  gStyle->SetPadBottomMargin(0.17); 

  // TFile* file = new TFile("./root/H_HT_HC_OCT23_2021_1.root");
  // TH1F* h = (TH1F*)file->Get("h_2_a");
 
  TFile *t1 = new TFile("./root/H_HT_OCT25_2021_1.root");//// correct kinematics
  TH1F *h = (TH1F*)t1->Get("h_2a");
  TH1F *h_bg = (TH1F*)t1->Get("h_2a_bg");
  h_bg->SetFillColor(kGreen+3);


  TFile* file1 = new TFile("./root/OCT7_HT_120_1.root");//// wrong kinematics
  TH1F* h1 = (TH1F*)file1->Get("h_2_2");

  h->GetXaxis()->SetTitle("-B_{#Lambda} (MeV)"); 
  h->GetXaxis()->SetTitleSize(0.07);
  h->GetXaxis()->SetTitleFont(62);//  32 gives the times italic bold
  h->GetXaxis()->SetTitleOffset(0.99);  
  h->GetXaxis()->CenterTitle();
  h->GetXaxis()->SetLabelSize(0.06);
  h->GetXaxis()->SetLabelFont(62); // 22 gives the times bold
 
  h->GetYaxis()->SetTitle("Counts / 0.75 MeV");
  h->GetYaxis()->CenterTitle();
  h->GetYaxis()->SetTitleSize(0.07);
  h->GetYaxis()->SetTitleFont(62);//  32 gives the times italic bold
  h->GetYaxis()->SetTitleOffset(1.15);
  h->GetYaxis()->SetLabelSize(0.06);
  h->GetYaxis()->SetLabelFont(62);

  ////////////////////////////////////////////////

  h1->GetXaxis()->SetTitle("-B_{#Lambda} (MeV)"); 
  h1->GetXaxis()->SetTitleSize(0.07);
  h1->GetXaxis()->SetTitleFont(62);//  32 gives the times italic bold
  h1->GetXaxis()->SetTitleOffset(0.99);  
  h1->GetXaxis()->CenterTitle();
  h1->GetXaxis()->SetLabelSize(0.06);
  h1->GetXaxis()->SetLabelFont(62); // 22 gives the times bold
 
  h1->GetYaxis()->SetTitle("Counts / 1.5 MeV");
  h1->GetYaxis()->CenterTitle();
  h1->GetYaxis()->SetTitleSize(0.07);
  h1->GetYaxis()->SetTitleFont(62);//  32 gives the times italic bold
  h1->GetYaxis()->SetTitleOffset(1.15);
  h1->GetYaxis()->SetLabelSize(0.06);
  h1->GetYaxis()->SetLabelFont(62);

  
  


  // 
  //  gPad->SetLogy(1);
  TF1 *f1 = new TF1("f1","gaus",-1,1);
  f1->SetLineWidth(2);
  f1->SetLineColor(kMagenta);
  //h->Fit("f1","MR0");// BP 
  
  TF1 *fun = new TF1("fun","crystalball(0)+pol4(5)",-20,80);//-80,80
 

  fun->SetParameter(0,8.32361e+01);  /// first 3 are gaussian parameters
  fun->SetParameter(1,-8.10308e-02);
  fun->SetParameter(2,1.36619e+00);
  fun->SetParameter(3,-1.57682e+00);
  fun->SetParameter(4,7.59348e-01);
 
  // fun->FixParameter(0,fun->GetParameter(0)*0.75);

  /// accdental parameters (4th order pol) 
  fun->FixParameter(5,0.266486);///2.63606e-01
  fun->FixParameter(6,-0.00171973);
  fun->FixParameter(7,-3.24495e-05);
  fun->FixParameter(8,1.47153e-07);//1.47153e-07
  fun->FixParameter(9,6.88e-10);
  fun->SetNpx(1000);
  fun->SetLineWidth(1);
  
  TCanvas *c = new TCanvas("c","c",800,800);
  // c->Divide(1,2);
  c->Divide(2,1);
  c->cd(1);
  h->Draw(); 
  //  h->Fit("fun","MR+");
  fun->Draw("same");
  h_bg->Draw("same");

  TLatex l;  //// close these lines to get the fitting parameters
  l.SetTextSize(0.07);
  l.SetTextFont(62);// time bold italic 62 current 02/18/2021
  l.DrawLatex(15,81.5,Form("p(e,e'K^{+})#Lambda"));

  TLatex ll;  //// close these lines to get the fitting parameters
  ll.SetTextSize(0.06);
  ll.SetTextFont(62);// time bold italic 62 current 02/18/2021
  ll.DrawLatex(-82,8,Form("Accidentals"));

  TLatex ll1;  //// close these lines to get the fitting parameters
  ll1.SetTextSize(0.033);
  // ll1.DrawLatex(5,50,Form("#color[2]{Mean = 1115.68 MeV}"));
  // ll1.DrawLatex(5,45,Form("#color[2]{Width #approx 3.12 MeV FWHM}"));
  // ll.DrawLatex(-82,50,Form("#color[2]{Mean = 1115.68 #pm 0.076 MeV}"));
  // ll.DrawLatex(-82,45,Form("#color[2]{Width #approx 3.12 #pm 0.07 MeV FWHM}"));
  /////------------------------------------------------------------------------------------------------------------------------

  double fit_min = 0;
  double fit_max = 150;
 
 

  TF1* f = new TF1( "f", FMM_Response, fit_min,fit_max, 7);
  f->SetParameter(0,2.7e0);///2.7e0
  f->SetParameter(1, 4.9e1);///4.4e1
  //f->SetParLimits(1, 4.7e1,4.9e1);///4.4e1  
  f->SetParameter(2, 9.6e+2);
  f->SetParameter(3, 4.1e0);
  f->SetParameter(4,1.0e11);
  f->SetParameter(5, 3.3e4);
  f->SetParameter(6, 1.4e-1); 
  f->SetNpx(10000);


  ///// with updated parameters Ocyober 16, 2021
  TF1* f2 = new TF1( "f2", FMM_Response, fit_min,fit_max, 7);
  f2->FixParameter(0,2.85391e+00);
  f2->FixParameter(1, 4.40467e+01);
  f2->FixParameter(2,1.02181e+03);
  f2->FixParameter(3, 3.87426e+00);
  f2->FixParameter(4,1.00000e+11);
  f2->FixParameter(5, 3.29989e+04);
  f2->FixParameter(6, 2.03331e-01);
  // f2->SetLineColor(3);
  f2->SetLineWidth(1);
  f2->SetNpx(10000);

  // gStyle->SetOptFit(1111);
  // TCanvas *c1 = new TCanvas("c1","c1",800,800);
  c->cd(2);
  h1->Draw();
  // h1->Fit(f, "MR+");
  f2->Draw("same");

  TLatex l1;  //// close these lines to get the fitting parameters
  l1.SetTextSize(0.07);
  l1.SetTextFont(62);// time bold italic 62 current 02/18/2021
  l1.DrawLatex(50,42,Form("^{3}H(e,e'K^{+})#Lambdann"));










}
