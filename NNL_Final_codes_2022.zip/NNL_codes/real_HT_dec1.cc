void real_HT_dec1()
{
  // TFile *T1  = new TFile("./root/H_HT_HC_OCT23_2021_1.root");
  TFile *T1  = new TFile("./root/H_HT_OCT25_2021_1.root");
  TH1F *h1 = (TH1F*)T1->Get("h_2");
  TH1F *h1_bg = (TH1F*)T1->Get("h_2bg");
  h1_bg->SetFillColor(kGreen+3);
  // gStyle->SetOptFit(11111);
  gStyle->SetOptStat(0);

  TH1F *hhb=(TH1F*)h1_bg->Clone();
  

  gStyle->SetPadRightMargin(0.08);
  gStyle->SetPadLeftMargin(0.14);
  gStyle->SetPadTopMargin(0.05);
  gStyle->SetPadBottomMargin(0.17); 
  h1->GetXaxis()->SetTitle("Missing Mass (MeV/    )"); 
  h1->GetXaxis()->SetTitleSize(0.07);
  h1->GetXaxis()->SetTitleFont(62);//  32 gives the times italic bold
  h1->GetXaxis()->SetTitleOffset(0.99);  
  h1->GetXaxis()->CenterTitle();
  h1->GetXaxis()->SetLabelSize(0.06);
  h1->GetXaxis()->SetLabelFont(62); // 22 gives the times bold
 
  h1->GetYaxis()->SetTitle("Counts / 0.75 MeV");
  h1->GetYaxis()->CenterTitle();
  h1->GetYaxis()->SetTitleSize(0.07);
  h1->GetYaxis()->SetTitleFont(62);//  32 gives the times italic bold
  h1->GetYaxis()->SetTitleOffset(0.8);
  h1->GetYaxis()->SetLabelSize(0.06);
  h1->GetYaxis()->SetLabelFont(62);


  
  TF1 *f1 = new TF1("f1","gaus",1112.52,1118.8);///1112.52,1118.8
  h1->Draw();
  h1->Fit("f1","MR0");

   ///// background function
  TF1 *f_bg = new TF1("f_bg","[0]+[1]*x+[2]*pow(x,2)+[3]*pow(x,3)+[4]*pow(x,4)+[5]*pow(x,5)+[6]*pow(x,6)",1025,1200);
  f_bg->FixParameter(0,-3.38855e+00);
  f_bg->FixParameter(1,3.54522e-04);
  f_bg->FixParameter(2,1.89718e-06);
  f_bg->FixParameter(3,1.95669e-09);
  f_bg->FixParameter(4,1.11113e-12);
  f_bg->FixParameter(5,-1.99771e-16);
  f_bg->FixParameter(6,-1.66214e-18);
  f_bg->SetLineColor(kGreen+3);
  
  TF1 *f2 = new TF1("f2","crystalball(0)+pol6(5)",1112.52,1118.8);
  f2->SetParameter(0,f1->GetParameter(0));
  f2->SetParameter(1,f1->GetParameter(1));
  f2->SetParameter(2,f1->GetParameter(2));
  f2->SetParameter(3,-1.5);
  f2->SetParameter(4,0.55);

  ///// background parameters
  f2->FixParameter(5,-3.38855e+00);
  f2->FixParameter(6,3.54522e-04);
  f2->FixParameter(7,1.89718e-06);
  f2->FixParameter(8,1.95669e-09);
  f2->FixParameter(9,1.11113e-12);
  f2->FixParameter(10,-1.99771e-16);
  f2->FixParameter(11,-1.66214e-18);
  f2->SetLineWidth(1);

  
  
 
  TCanvas *c1 = new TCanvas("c1","c1",800,800);
  c1->cd();
  h1->Draw();
  h1->Fit("f2","","",1050.0,1200.0);
  h1_bg->Draw("same");
  f_bg->Draw("same");
 
  TLatex l;  //// close these lines to get the fitting parameters
  l.SetTextSize(0.055);
  l.SetTextFont(62);// time bold italic 62 current 02/18/2021
  l.DrawLatex(1126,75,Form("#Lambda"));
  l.DrawLatex(1126,67,Form("#color[2]{Mean = 1115.68 #pm 0.075 MeV}"));
  l.DrawLatex(1126,57,Form("#color[2]{Width #approx 3.12 #pm 0.07 MeV FWHM}"));

  TLatex l1;  //// close these lines to get the fitting parameters
  l1.SetTextSize(0.06);
  l1.SetTextFont(62);
  l1.DrawLatex(1040,8,Form("Accidentals"));

  TLatex l5;  //// close these lines to get the fitting parameters
  l5.SetTextSize(0.07);
  l5.SetTextFont(72);
  l5.DrawLatex(1195.57,-15.5,Form("c^{2}"));
 
  

  // TF1 *f_bg = new TF1("f_bg","[0]+[1]*x+[2]*pow(x,2)+[3]*pow(x,3)+[4]*pow(x,4)+[5]*pow(x,5)+[6]*pow(x,6)",1025,1200);
  
  // TCanvas *c2 = new TCanvas("c2","c2",800,800);
  // c2->cd();
  // hhb->Draw("E2");
  // hhb->Fit("f_bg","MR+");
  // hhb->SetFillStyle(3002);
  // hhb->SetMarkerStyle(28);
  // hhb->SetMarkerColor(kGreen);
  
}
