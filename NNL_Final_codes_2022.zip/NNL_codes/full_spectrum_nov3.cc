// copied from Final_fit_OCT21.cc
// In this code the free Lambfa (Hcontamination) function will be included in the Sigma QF function
// In this code the Free lambda (H contamination) function is taken from the fitting of the real data 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999
///// this function is used to draw the Free Lambda underneath the Lnn spectrum99999999999999999999999999999999999999999999999
//// Function taken from ~/Desktop/OCT_2021/SIMA_OCT11$  FREE_LAMBDA.cc
double L_underneath( double *x, double *par ){
  double invsq2pi = 0.3989422804014;   // (2 pi)^(-1/2)
  double mpshift  = -0.22278298;       // Landau maximum location
  double np = 500.0;      // number of convolution steps
  double sc =   5.0;      // convolution extends to +-sc Gaussian sigmas
  double xx, mpc, fland, sum = 0.0, xlow,xupp, step, i;
  double val1, val2;

  // MP shift correction
  mpc = par[1] - mpshift * par[0];
  // Range of convolution integral
  xlow = x[0] - sc * par[3];
  xupp = x[0] + sc * par[3];
  step = (xupp-xlow) / np;
  // Convolution integral of Landau and Gaussian by sum
  for(i=1.0; i<=np/2; i++) {
	xx = xlow + (i-.5) * step;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);

	xx = xupp - (i-.5) * step;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);
  }
  val1 = step * sum * invsq2pi / par[3];

  /*------Landau * Gauss convluted------*/

  // Range of convolution integral
  sum  = 0.;
  xlow = 0.;
  xupp = x[0] + 1.6 * sc * par[3];
  step = (xupp-xlow) / np;
  if(step<0.)step = 0.;
  // Convolution integral
  for(i=1.0; i<=np/2; i++){
	xx = xlow + (i-0.5) * step - par[5];
	fland = TMath::Gaus(xx,x[0],par[3]);
	sum += fland * TMath::Exp(-xx/par[4]);
	xx = xupp - (i-.5) * step - par[5];
	fland = TMath::Gaus(xx,x[0],par[3]);
	sum += fland * TMath::Exp(-xx/par[4]);
  }
  //val = par[2] * step * sum * invsq2pi / par[3];
  val2 =  step * sum * invsq2pi / (par[3]*par[4]*exp(par[5]/par[4]));
  //val2 =  step * sum * invsq2pi / (par[3]*par[4]);
  /*------Exp * Gauss convluted------*/

  return par[2]*(val1+par[6]*val2)/(1.+par[6]);//N x (Landau*Gauss) + N' x (Exp*Gauss)

}/// end of L_underneath


///999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999
/////....................................................................................................................................

double  FREE_LAMBDA( double *x, double *par ){//copied from result_2D.C (2020/12/21)
  
  double invsq2pi = 0.3989422804014;   
  double mpshift  = -0.22278298;       
  double np = 500.0;     
  double sc =   5.0;     
  double xx, mpc, fland, sum = 0.0, xlow,xupp, step, i;
  double val1, val2;

  // MP shift correction
  mpc = par[1] - mpshift * par[0];
  // Range of convolution integral
  xlow = x[0] - sc * par[3];
  xupp = x[0] + sc * par[3];
  step = (xupp-xlow) / np;
  // Convolution integral of Landau and Gaussian by sum
  for(i=1.0; i<=np/2; i++) {
	xx = xlow + (i-.5) * step;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);

	xx = xupp - (i-.5) * step;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);
  }
  val1 = step * sum * invsq2pi / par[3];

  //------Landau * Gauss convluted------//

  // Range of convolution integral
  sum  = 0.;
  xlow = 0.;
  xupp = x[0] + 1.6 * sc * par[3];
  step = (xupp-xlow) / np;
  if(step<0.)step = 0.;
  // Convolution integral
  for(i=1.0; i<=np/2; i++){
	xx = xlow + (i-0.5) * step - par[5];
	fland = TMath::Gaus(xx,x[0],par[3]);
	sum += fland * TMath::Exp(-xx/par[4]);
	xx = xupp - (i-.5) * step - par[5];
	fland = TMath::Gaus(xx,x[0],par[3]);
	sum += fland * TMath::Exp(-xx/par[4]);
  }
 
  val2 =  step * sum * invsq2pi / (par[3]*par[4]*exp(par[5]/par[4]));
 
  //------Exp * Gauss convluted------//

  //  return par[2]*(val1+par[6]*val2)/(1.+par[6]);//N x (Landau*Gauss) + N' x (Exp*Gauss)

  ////  B is defined because the Lambda QF shape is going below the Acc shape after acc included
  double B1= par[2] *(val1+par[6]);// Lambda QF shape
  if(B1<0.0){B1=0.0;}
  
  ///// A is the background function which is a known functiondouble
  double A1= par[7]+par[8]*x[0]+par[9]*pow(x[0],2)+par[10]*pow(x[0],3)+par[11]*pow(x[0],4) +par[12]*pow(x[0],5)+par[13]*pow(x[0],6);
  A1= par[14]*A1;
  
  
  /////He contamination function
  double C1 =  par[15]*exp(-0.5*pow((x[0]-par[16])/par[17],2))+ par[18]+par[19]*x[0]+par[20]*pow(x[0],2)+par[21]*pow(x[0],3)+par[22]*pow(x[0],4)+par[23]*pow(x[0],5)+par[24]*pow(x[0],6);
  
  C1 = C1*par[25];
  if(x[0]<0.0){C1=0.0;}
  
  
  ////////////////////////////// new fun to include the Free Lambda part >>>>>>>>>>>##############################################
  double sc1 =   5.0;     
  double xx1, mpc1, fland1, sum1 = 0.0, xlow1,xupp1, step1;
  
  double val3, val4;
  
  // MP shift correction
  mpc1 = par[27] - mpshift * par[26];// par[1] = 27
  // Range of convolution integral
  xlow1 = x[0] - sc1 * par[29];
  xupp1 = x[0] + sc1 * par[29];
  step1 = (xupp1-xlow1) / np;
  // Convolution integral of Landau and Gaussian by sum
  for(i=1.0; i<=np/2; i++) {
    xx1 = xlow1 + (i-.5) * step1;
    fland1 = TMath::Landau(xx1,mpc1,par[26]) / par[26];
    sum1 += fland1 * TMath::Gaus(x[0],xx1,par[29]);
    
    xx1 = xupp1 - (i-.5) * step1;
    fland1 = TMath::Landau(xx1,mpc1,par[26]) / par[26];
    sum1 += fland1 * TMath::Gaus(x[0],xx1,par[29]);
  }
  val3 = step1 * sum1 * invsq2pi / par[29];
  
  //------Landau * Gauss convluted------//
  
  // Range of convolution integral
  sum1  = 0.;
  xlow1 = 0.;
  xupp1 = x[0] + 1.6 * sc1 * par[29];
  step1 = (xupp1-xlow1) / np;
  if(step1<0.)step1 = 0.;
  // Convolution integral
  for(i=1.0; i<=np/2; i++){
    xx1 = xlow1 + (i-0.5) * step1 - par[31];
    fland1 = TMath::Gaus(xx1,x[0],par[29]);
    sum1 += fland1 * TMath::Exp(-xx1/par[30]);
    xx1 = xupp1 - (i-.5) * step1 - par[31];
    fland1 = TMath::Gaus(xx1,x[0],par[29]);
    sum1 += fland1 * TMath::Exp(-xx1/par[30]);
  }
  
  val4 =  step1 * sum1 * invsq2pi / (par[29]*par[30]*exp(par[31]/par[30]));// BP oct22 updated
  
  double R = par[28]*(val3+par[32]*val4)/(1.+par[32]);// R is the free Lambda from H contamination
  
  
  ////////////////////////////// ne fun>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>###############################################
  // return C1;//// He contamination
  return A1+B1+C1 +R; ///// BG shape real data
  
}

////////////////// copying FREE_LAMBDA function as LAMBDA_QF shape((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((
double  LAMBDA_QF( double *x, double *par ){//copied from result_2D.C (2020/12/21)
  
  double invsq2pi = 0.3989422804014;   
  double mpshift  = -0.22278298;       
  double np = 500.0;     
  double sc =   5.0;     
  double xx, mpc, fland, sum = 0.0, xlow,xupp, step, i;
  double val1, val2;

  // MP shift correction
  mpc = par[1] - mpshift * par[0];
  // Range of convolution integral
  xlow = x[0] - sc * par[3];
  xupp = x[0] + sc * par[3];
  step = (xupp-xlow) / np;
  // Convolution integral of Landau and Gaussian by sum
  for(i=1.0; i<=np/2; i++) {
	xx = xlow + (i-.5) * step;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);

	xx = xupp - (i-.5) * step;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);
  }
  val1 = step * sum * invsq2pi / par[3];

  //------Landau * Gauss convluted------//

  // Range of convolution integral
  sum  = 0.;
  xlow = 0.;
  xupp = x[0] + 1.6 * sc * par[3];
  step = (xupp-xlow) / np;
  if(step<0.)step = 0.;
  // Convolution integral
  for(i=1.0; i<=np/2; i++){
	xx = xlow + (i-0.5) * step - par[5];
	fland = TMath::Gaus(xx,x[0],par[3]);
	sum += fland * TMath::Exp(-xx/par[4]);
	xx = xupp - (i-.5) * step - par[5];
	fland = TMath::Gaus(xx,x[0],par[3]);
	sum += fland * TMath::Exp(-xx/par[4]);
  }
 
  val2 =  step * sum * invsq2pi / (par[3]*par[4]*exp(par[5]/par[4]));
 
  //------Exp * Gauss convluted------//

  //  return par[2]*(val1+par[6]*val2)/(1.+par[6]);//N x (Landau*Gauss) + N' x (Exp*Gauss)

  ////  B is defined because the Lambda QF shape is going below the Acc shape after acc included
  double B1= par[2] *(val1+par[6]);// Lambda QF shape
  if(B1<0.0){B1=0.0;}
  
  ///// A is the background function which is a known functiondouble
  double A1= par[7]+par[8]*x[0]+par[9]*pow(x[0],2)+par[10]*pow(x[0],3)+par[11]*pow(x[0],4) +par[12]*pow(x[0],5)+par[13]*pow(x[0],6);
  A1= par[14]*A1;
  
  
  /////He contamination function
  double C1 =  par[15]*exp(-0.5*pow((x[0]-par[16])/par[17],2))+ par[18]+par[19]*x[0]+par[20]*pow(x[0],2)+par[21]*pow(x[0],3)+par[22]*pow(x[0],4)+par[23]*pow(x[0],5)+par[24]*pow(x[0],6);
  
  C1 = C1*par[25];
  if(x[0]<0.0){C1=0.0;}
  
  
   
  ////////////////////////////// ne fun>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>###############################################
  // return C1;//// He contamination
  return A1+B1+C1; ///// BG shape real data
  
}
////////////////// copied FREE_LABDA function as LAMBDA_QF shape))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))


///////////////////// a new function for  the Sigma QF shapexxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
double  SIGMA_QF( double *x, double *par ){//copied from result_2D.C (2020/12/21)
  
  double invsq2pi = 0.3989422804014;   
  double mpshift  = -0.22278298;       
  double np = 500.0;     
  double sc =   5.0;     
  double xx, mpc, fland, sum = 0.0, xlow,xupp, step, i;
  double val1, val2;

  // MP shift correction
  mpc = par[1] - mpshift * par[0];
  // Range of convolution integral
  xlow = x[0] - sc * par[3];
  xupp = x[0] + sc * par[3];
  step = (xupp-xlow) / np;
  // Convolution integral of Landau and Gaussian by sum
  for(i=1.0; i<=np/2; i++) {
	xx = xlow + (i-.5) * step;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);

	xx = xupp - (i-.5) * step;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);
  }
  val1 = step * sum * invsq2pi / par[3];

  //------Landau * Gauss convluted------//

  // Range of convolution integral
  sum  = 0.;
  xlow = 0.;
  xupp = x[0] + 1.6 * sc * par[3];
  step = (xupp-xlow) / np;
  if(step<0.)step = 0.;
  // Convolution integral
  for(i=1.0; i<=np/2; i++){
	xx = xlow + (i-0.5) * step - par[5];
	fland = TMath::Gaus(xx,x[0],par[3]);
	sum += fland * TMath::Exp(-xx/par[4]);
	xx = xupp - (i-.5) * step - par[5];
	fland = TMath::Gaus(xx,x[0],par[3]);
	sum += fland * TMath::Exp(-xx/par[4]);
  }
 
  val2 =  step * sum * invsq2pi / (par[3]*par[4]*exp(par[5]/par[4]));
 
  //------Exp * Gauss convluted------//

  //  return par[2]*(val1+par[6]*val2)/(1.+par[6]);//N x (Landau*Gauss) + N' x (Exp*Gauss)

  ////  B is defined because the Lambda QF shape is going below the Acc shape after acc included
  double B1= par[2] *(val1+par[6]);// Lambda QF shape
  if(B1<0.0){B1=0.0;}
  
  ///// A is the background function which is a known functiondouble
  double A1= par[7]+par[8]*x[0]+par[9]*pow(x[0],2)+par[10]*pow(x[0],3)+par[11]*pow(x[0],4) +par[12]*pow(x[0],5)+par[13]*pow(x[0],6);
  A1= par[14]*A1;
  
  
  /////He contamination function
  double C1 =  par[15]*exp(-0.5*pow((x[0]-par[16])/par[17],2))+ par[18]+par[19]*x[0]+par[20]*pow(x[0],2)+par[21]*pow(x[0],3)+par[22]*pow(x[0],4)+par[23]*pow(x[0],5)+par[24]*pow(x[0],6);
  
  C1 = C1*par[25];
  if(x[0]<0.0){C1=0.0;}
  
  
  ////////////////////////////// new fun to include the Free Lambda part >>>>>>>>>>>##############################################
  double sc1 =   5.0;     
  double xx1, mpc1, fland1, sum1 = 0.0, xlow1,xupp1, step1;
  
  double val3, val4;
  
  // MP shift correction
  mpc1 = par[27] - mpshift * par[26];// par[1] = 27
  // Range of convolution integral
  xlow1 = x[0] - sc1 * par[29];
  xupp1 = x[0] + sc1 * par[29];
  step1 = (xupp1-xlow1) / np;
  // Convolution integral of Landau and Gaussian by sum
  for(i=1.0; i<=np/2; i++) {
    xx1 = xlow1 + (i-.5) * step1;
    fland1 = TMath::Landau(xx1,mpc1,par[26]) / par[26];
    sum1 += fland1 * TMath::Gaus(x[0],xx1,par[29]);
    
    xx1 = xupp1 - (i-.5) * step1;
    fland1 = TMath::Landau(xx1,mpc1,par[26]) / par[26];
    sum1 += fland1 * TMath::Gaus(x[0],xx1,par[29]);
  }
  val3 = step1 * sum1 * invsq2pi / par[29];
  
  //------Landau * Gauss convluted------//
  
  // Range of convolution integral
  sum1  = 0.;
  xlow1 = 0.;
  xupp1 = x[0] + 1.6 * sc1 * par[29];
  step1 = (xupp1-xlow1) / np;
  if(step1<0.)step1 = 0.;
  // Convolution integral
  for(i=1.0; i<=np/2; i++){
    xx1 = xlow1 + (i-0.5) * step1 - par[31];
    fland1 = TMath::Gaus(xx1,x[0],par[29]);
    sum1 += fland1 * TMath::Exp(-xx1/par[30]);
    xx1 = xupp1 - (i-.5) * step1 - par[31];
    fland1 = TMath::Gaus(xx1,x[0],par[29]);
    sum1 += fland1 * TMath::Exp(-xx1/par[30]);
  }
  
  val4 =  step * sum1 * invsq2pi / (par[29]*par[30]*exp(par[31]/par[30]));
  
  double R = par[28]*(val3+par[32]*val4)/(1.+par[32]);// R is the free Lambda from H contamination

  /////^^^^^^^^^^^^^^^^^^^^Now need to include the Sigma QF function^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  
  ////// SIgma QF function
  double D1 =   par[33]*exp(-0.5*pow((x[0]-par[34])/par[35],2))+ par[36]+par[37]*x[0]+par[38]*pow(x[0],2)+par[39]*pow(x[0],3)+par[40]*pow(x[0],4)+par[41]*pow(x[0],5)+par[42]*pow(x[0],6);
  
  D1 = D1*par[43];
  if(x[0]<0.0){D1=0.0;}
  /////^^^^^^^^^^^^^^^^^^^^Now need to include the Sigma QF function^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  
  ////////////////////////////// ne fun>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>###############################################
  // return C1;//// He contamination
  return A1+B1+C1+D1+R; ///// BG shape real data
  
}
///////////////  up to here function for  the Sigma QF shapexxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

void full_spectrum_nov3()
{
  gStyle->SetOptStat(0);
  // gStyle->SetOptFit(1111111);
  
  //  gStyle->SetStatFont(62);
  // gStyle->SetStatFontSize(0.05);
  //gStyle->SetStatTextColor(2);
  
  gStyle->SetPadRightMargin(0.08);
  gStyle->SetPadLeftMargin(0.14);
  gStyle->SetPadTopMargin(0.05);
  gStyle->SetPadBottomMargin(0.17);

  
  
  
  TFile * f_qu = new TFile("./root/Widerbin_nnl_NOV2_1.root"); //// Lnn spectrum  
  TH1F *h_22 = (TH1F*)f_qu->Get("h125_4");////original Range (173,-103.55,156.35)
  TH1F *h_22b = (TH1F*)f_qu->Get("h125_4b");
  h_22b->SetMarkerColor(kGreen+3);
  TH1F *hcp = (TH1F*)h_22b->Clone();

  h_22->GetXaxis()->SetTitle("-B_{#Lambda} (MeV)"); // Tritium target for H kinematics
  h_22->GetXaxis()->SetTitleSize(0.07);
  h_22->GetXaxis()->SetTitleFont(62);//  32 gives the times italic bold
  h_22->GetXaxis()->SetTitleOffset(1.05);  
  h_22->GetXaxis()->CenterTitle();
  h_22->GetXaxis()->SetLabelSize(0.06);
  h_22->GetXaxis()->SetLabelFont(62); // 22 for times bold
  
  h_22->GetYaxis()->SetTitle("Counts / 2.5 MeV");
  h_22->GetYaxis()->CenterTitle();
  h_22->GetYaxis()->SetTitleSize(0.07);
  h_22->GetYaxis()->SetTitleFont(62);//  32 gives the times italic bold  // 22 gives times bold
  h_22->GetYaxis()->SetTitleOffset(0.65);
  h_22->GetYaxis()->SetLabelSize(0.06);
  h_22->GetYaxis()->SetLabelFont(62); // for times bold


  
    
  //////// free lambda with Lamba QF,ACC and He contamination$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
  
  TF1* free_lambda = new TF1( "free_lambda",  FREE_LAMBDA,30.0,75.2,33);// display range  
  ////// parameters from Lambda QF function (Gaussian convoluted with Landau function)
  free_lambda->FixParameter(0,1.45335e+01);
  free_lambda->FixParameter(1, 4.12429e+01);///
  
  //// free_lambda->SetParameter(2,2.47280e+06);// original/// 

  // free_lambda->SetParameter(2,3.30114e+03); //original need to scale with 1.6667
  free_lambda->SetParameter(2,5.502e+03); // scaled with 1.6667

  free_lambda->FixParameter(3,1.94758e+01);//
  free_lambda->FixParameter(4,1.00000e+11);//9.95232e+10
  free_lambda->FixParameter(5, 3.30000e+04);//
  free_lambda->FixParameter(6, -1.38979e-03);  
 
  // free_lambda->SetParameter(2,free_lambda->GetParameter(2)*0.0012);  //// This parameter is fitted 
 
 // ///// Paramaters obtained from the background fitting
  free_lambda->FixParameter(7,1.01932e+01);/// BP OCT 16
  free_lambda->FixParameter(8,3.46367e-02);
  free_lambda->FixParameter(9,-9.11794e-04);
  free_lambda->FixParameter(10,-1.22389e-06);
  free_lambda->FixParameter(11,4.05084e-08);
  free_lambda->FixParameter(12,-8.39054e-11);
  free_lambda->FixParameter(13,-3.49195e-13);

  free_lambda->FixParameter(14,1.0);/// ACCdintel shape  
 
  // ////// These are the He contamination parameters 
  free_lambda->FixParameter(15,1.34700e+04);///0.000096*
  free_lambda->FixParameter(16,5.16891e+01);
  free_lambda->FixParameter(17,2.37999e+01);  
  // /// Sixthe order updated obtained by fittinh a sixth polynomial in the while range
  free_lambda->FixParameter(18,-1.15972e+03);
  free_lambda->FixParameter(19,-1.40280e+02);
  free_lambda->FixParameter(20,7.55137e+00);
  free_lambda->FixParameter(21,2.32356e-02);
  free_lambda->FixParameter(22,-1.86532e-03);
  free_lambda->FixParameter(23,1.45534e-05);
  free_lambda->FixParameter(24,-3.39134e-08);
  free_lambda->FixParameter(25,0.000096*1.6667);/// scaling factor for the Lambda QF shape


  ////// Free Lambda from H contamination
  ///(got these parameters by fitting/Desktop/OCT_2021/SIMA_OCT11$  FREE_LAMBDA.cc)
  free_lambda->FixParameter(26,2.85391e+00);
  free_lambda->FixParameter(27, 4.40467e+01);
  free_lambda->FixParameter(28,1.28561e+03);//1.28561e+03
  free_lambda->FixParameter(29, 3.87426e+00);
  free_lambda->FixParameter(30,9.95232e+10);
  free_lambda->FixParameter(31, 3.29989e+04);
  free_lambda->FixParameter(32, 2.03331e-01);  

    
  free_lambda->FixParameter(28,free_lambda->GetParameter(28)*0.30*1.6667);/// Optimized on OCT 20, 2021
  /// cout<<" the value of par 28  is = " <<free_lambda->GetParameter(28)<<endl; 
  
  free_lambda->SetNpx(1000);

  ///// copying the free_lambda function to a new function L_QF function
  ///+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  TF1* L_QF = new TF1( "L_QF",  LAMBDA_QF,-200.0,160.0,26);// display range  
  ////// parameters from Lambda QF fnction (Gaussian convoluted with Landau function)
  L_QF->FixParameter(0,1.45335e+01);//////1.45335e+01   BP nov 3  ++@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 
  L_QF->FixParameter(1, 4.12429e+01);///
  //// L_QF->FixParameter(2,2.47280e+06);// original/// keep coment when fitted by using 246 line
 
  // L_QF->FixParameter(2,3.30114e+03); //original need to be scaled by 1.6667
  L_QF->FixParameter(2,5.502e+03); // scaled by 1.6667

  L_QF->FixParameter(3,1.94758e+01);//
  L_QF->FixParameter(4,9.95232e+10);//
  L_QF->FixParameter(5, 3.30000e+04);//
  L_QF->FixParameter(6, -1.38979e-03);  
 
  // L_QF->SetParameter(2,L_QF->GetParameter(2)*0.0012);  //// This parameter is fitted (scaling factor of the L qf function) 
 
 // ///// Paramaters obtained from the background fitting
  L_QF->FixParameter(7,1.01932e+01);/// BP OCT 16
  L_QF->FixParameter(8,3.46367e-02);
  L_QF->FixParameter(9,-9.11794e-04);
  L_QF->FixParameter(10,-1.22389e-06);
  L_QF->FixParameter(11,4.05084e-08);
  L_QF->FixParameter(12,-8.39054e-11);
  L_QF->FixParameter(13,-3.49195e-13);

  L_QF->FixParameter(14,1.0);/// ACCdintel shape  
 // ////// These are the He contamination parameters 
  L_QF->FixParameter(15,1.34700e+04);///0.000096*
  L_QF->FixParameter(16,5.16891e+01);
  L_QF->FixParameter(17,2.37999e+01);  
  // /// Sixthe order updated obtained by fittinh a sixth polynomial in the while range
  L_QF->FixParameter(18,-1.15972e+03);
  L_QF->FixParameter(19,-1.40280e+02);
  L_QF->FixParameter(20,7.55137e+00);
  L_QF->FixParameter(21,2.32356e-02);
  L_QF->FixParameter(22,-1.86532e-03);
  L_QF->FixParameter(23,1.45534e-05);
  L_QF->FixParameter(24,-3.39134e-08);
  L_QF->FixParameter(25,0.000096*1.6667);/// scaling He contamination

  L_QF->SetLineStyle(2);
  
  ///++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  ///??????????????? function for Sigma QF shape?????????????????????????????????????????????????????????????????????????????????????
  TF1* S_QF = new TF1( "S_QF",  SIGMA_QF,75.,156.0,44);// display range  
  ////// parameters from Lambda QF fnction (Gaussian convoluted with Landau function)
  S_QF->FixParameter(0,1.45335e+01);
  S_QF->FixParameter(1, 4.12429e+01);///
  //// S_QF->FixParameter(2,2.47280e+06);// original/// keep coment when fitted by using 246 line
 
  // S_QF->FixParameter(2,3.30514e+03); //original need to be scaled by 1.6667
  S_QF->FixParameter(2,5.502e03); //scaled with 1.6667

  S_QF->FixParameter(3,1.94758e+01);//
  S_QF->FixParameter(4,9.95232e+10);//
  S_QF->FixParameter(5, 3.30000e+04);//
  S_QF->FixParameter(6, -1.38979e-03);  
 
 // S_QF->SetParameter(2,S_QF->GetParameter(2)*0.0018);  //// This parameter is fitted  
 
 // ///// Paramaters obtained from the background fitting
  S_QF->FixParameter(7,1.01932e+01);/// BP OCT 16
  S_QF->FixParameter(8,3.46367e-02);
  S_QF->FixParameter(9,-9.11794e-04);
  S_QF->FixParameter(10,-1.22389e-06);
  S_QF->FixParameter(11,4.05084e-08);
  S_QF->FixParameter(12,-8.39054e-11);
  S_QF->FixParameter(13,-3.49195e-13);

  S_QF->FixParameter(14,1.0);/// ACCdintel shape

  
 // ////// These are the He contamination parameters 
  S_QF->FixParameter(15,1.34700e+04);///0.000096*
  S_QF->FixParameter(16,5.16891e+01);
  S_QF->FixParameter(17,2.37999e+01);  
  // /// Sixth order updated obtained by fittinh a sixth polynomial in the while range
  S_QF->FixParameter(18,-1.15972e+03);
  S_QF->FixParameter(19,-1.40280e+02);
  S_QF->FixParameter(20,7.55137e+00);
  S_QF->FixParameter(21,2.32356e-02);
  S_QF->FixParameter(22,-1.86532e-03);
  S_QF->FixParameter(23,1.45534e-05);
  S_QF->FixParameter(24,-3.39134e-08);
  S_QF->FixParameter(25,0.000096*1.6667);/// scaling factor for the Lambda QF shape


  ////// Free Lambda from H contamination 
  ///(got these parameters by fitting/Desktop/OCT_2021/SIMA_OCT11$  FREE_LAMBDA.cc)
  S_QF->FixParameter(26,2.85391e+00);
  S_QF->FixParameter(27, 4.40467e+01);
  //  S_QF->FixParameter(28,1.28561e+03);// original before nov 2, 2021
  S_QF->FixParameter(28,1.388e+03);//1.02181e+03)//3.34951e+02,1.28561e03-----------------------> BP nov 3, 2021

  S_QF->FixParameter(29, 3.87426e+00);
  S_QF->FixParameter(30,9.95232e+10);
  S_QF->FixParameter(31, 3.29989e+04);
  S_QF->FixParameter(32, 2.03331e-01); 
 
  S_QF->FixParameter(28,S_QF->GetParameter(28)*0.30*1.6667);/// Optimized on OCT 20, 2021

  ////// parameters for the Sigma QF shape---------------------------------------------><>>>>>>>>>>>>>>>>>>>>>>>
  S_QF->FixParameter(33,2.94066e+04);///2.94066e+04
  S_QF->FixParameter(34,1.22014e+02);//1.22014e+02
  S_QF->FixParameter(35,2.19876e+01); // 2.19876e+01
  // /// Sixthe order updated obtained by fittinh a sixth polynomial in the while range
  S_QF->FixParameter(36,-2.92745e+05);//-2.92745e+05.............-2.95745e+05
  S_QF->FixParameter(37,1.32625e+04);//1.33525e+04...................1.32525e+04
  S_QF->FixParameter(38,-2.21779e+02);//-2.21779e+02
  S_QF->FixParameter(39,1.17716e+00);//1.17716e+00
  S_QF->FixParameter(40,6.79397e-03);//6.79397e-03
  S_QF->FixParameter(41,-9.04815e-05);//-9.03715e-05-->original Nov 3
  S_QF->FixParameter(42,2.40686e-07);//2.40686e-07
  
  //S_QF->SetParameter(43,0.0001);/// initially SetParameter(36,0.0001);
  // S_QF->FixParameter(43,3.96462e-05);// original before 5m Nov 3, 2021
  S_QF->FixParameter(43,3.96462e-05*1.7);//----------------------------->>>>>>>>>>>>>>>>>>>>>>>>>BP NOV 3, 2021 

  S_QF->SetNpx(1000);

  // S_QF->SetLineColor(kBlue);
  // S_QF->SetLineStyle(2);


  ///???????????????up to here  function for Sigma QF shape??????????????????????????????????????????????????????????????????????????????

  // ///// ^^^^^^^^^^^^^Accidental background function^^^^^^^^^^^^^^^^^
  TF1 *f_bg = new TF1("f_bg","[0]+[1]*x+[2]*pow(x,2)+[3]*pow(x,3)+[4]*pow(x,4) +[5]*pow(x,5)+[6]*pow(x,6)", -4.2,160.);
  f_bg->FixParameter(0,1.01932e+01);
  f_bg->FixParameter(1,3.46367e-02);
  f_bg->FixParameter(2,-9.11794e-04);
  f_bg->FixParameter(3,-1.22389e-06);
  f_bg->FixParameter(4,4.05084e-08);
  f_bg->FixParameter(5,-8.39054e-11);
  f_bg->FixParameter(6,-3.49195e-13);

  f_bg->SetLineColor(6);
  f_bg->SetLineStyle(3); 
  f_bg->SetNpx(100);  
 // ///// ^^^^^^^^^^^^^Accidental background function^^^^^^^^^^^^^^^^^
  TF1 *f_bg1 = new TF1("f_bg1","[0]+[1]*x+[2]*pow(x,2)+[3]*pow(x,3)+[4]*pow(x,4) +[5]*pow(x,5)+[6]*pow(x,6)", -100.,-4.3);
  f_bg1->FixParameter(0,1.01932e+01);
  f_bg1->FixParameter(1,3.46367e-02);
  f_bg1->FixParameter(2,-9.11794e-04);
  f_bg1->FixParameter(3,-1.22389e-06);
  f_bg1->FixParameter(4,4.05084e-08);
  f_bg1->FixParameter(5,-8.39054e-11);
  f_bg1->FixParameter(6,-3.49195e-13);

  f_bg1->SetNpx(1000);  
  ///// He contamination function +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  TF1 *f_He = new TF1("f_He","1.6667*0.000096*(gaus(0)+[3]+[4]*x+[5]*pow(x,2)+[6]*pow(x,3)+[7]*pow(x,4)+[8]*pow(x,5)+[9]*pow(x,6))",3.,153.);
  f_He->FixParameter(0,1.34700e+04);////// scale function = 0.000096*
  f_He->FixParameter(1,5.16891e+01);
  f_He->FixParameter(2,2.37999e+01);
  
  /// Sixthe order updated obtained by fittinh a sixth polynomial in the while range
  f_He->FixParameter(3,-1.15972e+03);
  f_He->FixParameter(4,-1.40280e+02);
  f_He->FixParameter(5,7.55137e+00);
  f_He->FixParameter(6,2.32356e-02);
  f_He->FixParameter(7,-1.86532e-03);
  f_He->FixParameter(8,1.45534e-05);
  f_He->FixParameter(9,-3.39134e-08);
  
  f_He->SetLineColor(6);
  f_He->SetFillColor(6);
  f_He->SetFillStyle(3144);
  // f_He->SetFillStyle(1001);
  f_He->SetNpx(1000);
  ///// 66666666666666666666666666666666666666666666666666666666666666666666
  /// free Lambda for underneath

  TF1* L_under = new TF1( "L_under", L_underneath, 20,150., 7);
  L_under->FixParameter(0,2.85391e+00);
  L_under->FixParameter(1, 4.40467e+01);
  L_under->FixParameter(2,1.28561e+03);
  L_under->FixParameter(3, 3.87426e+00);
  L_under->FixParameter(4,9.95232e+10);
  L_under->FixParameter(5, 3.29989e+04);
  L_under->FixParameter(6, 2.03331e-01);
 
  L_under->FixParameter(2,L_under->GetParameter(2)*0.30*1.6667);/// Optimized on OCT 20, 2021
  L_under->SetLineColor(kBlue);
  // L_under->SetLineStyle(2);
  L_under->SetNpx(10000);

  ////66666666666666666666666666666666666666666666666666666666666666666666666666
  ////====================From here Simulated Lambda QF shape fitting to the real nnL spectrum==<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
  TCanvas *c7 = new TCanvas("c7","c7",800,800);
  c7->cd();  
  h_22->Draw();
  h_22b->Draw("E2 same");
  f_bg->Draw("same");
  f_bg1->Draw("same");
  f_He->Draw("same");// BP oct 28
  L_under->Draw("same"); ///BP oct 2028

  // h_22->Fit("free_lambda","","", 30.0,80.); //B= Boundaries, fitting range= 30.0,80.0) 
  free_lambda->Draw("same");
 
  //h_22->Fit("L_QF","","", 30.0,80.0); //B= Boundaries fitting range= 30.0,80.0) 
  L_QF->Draw("same");// BP oct 28
  

  // h_22->Fit("S_QF","","", 80.0,150.0); // Boundaries Fit Range
  S_QF->Draw("same"); // BP oct28
  
  
  // TF1 *f_bg5 = new TF1("f_bg5","[0]+[1]*x+[2]*pow(x,2)+[3]*pow(x,3)+[4]*pow(x,4) +[5]*pow(x,5)+[6]*pow(x,6)", -98.,150.);
  // TCanvas *c = new TCanvas("c","c",800,800);
  // c->cd();
  // hcp->Draw();
  // hcp->Fit("f_bg5","","",-98,150);
 
}
