void HH_data_oct26(){
  // gStyle->SetOptFit(111);
  gStyle->SetOptStat(0);
  TFile *t1 = new TFile("./root/H_HT_OCT25_2021_1.root");
  TH1F *h1 = (TH1F*)t1->Get("h12");//h10
  TH1F *h1_bg = (TH1F*)t1->Get("h12_bg");//h10_bg
  h1_bg->SetLineColor(kGreen+3);

  TH1F *hhb=(TH1F*)h1_bg->Clone();
  h1_bg->SetFillColor(kGreen+3);

  
  gStyle->SetOptStat(0);
  gStyle->SetPadRightMargin(0.08);
  gStyle->SetPadLeftMargin(0.14);
  gStyle->SetPadTopMargin(0.05);
  gStyle->SetPadBottomMargin(0.17); 

  h1->GetXaxis()->SetTitle("Missing Mass (MeV/    )"); 
  h1->GetXaxis()->SetTitleSize(0.07);
  h1->GetXaxis()->SetTitleFont(62);//  32 gives the times italic bold
  h1->GetXaxis()->SetTitleOffset(0.99);  
  h1->GetXaxis()->CenterTitle();
  h1->GetXaxis()->SetLabelSize(0.06);
  h1->GetXaxis()->SetLabelFont(62); // 22 gives the times bold
 
  h1->GetYaxis()->SetTitle("Counts / 0.75 MeV");
  h1->GetYaxis()->CenterTitle();
  h1->GetYaxis()->SetTitleSize(0.07);
  h1->GetYaxis()->SetTitleFont(62);//  32 gives the times italic bold
  h1->GetYaxis()->SetTitleOffset(0.8);
  h1->GetYaxis()->SetLabelSize(0.06);
  h1->GetYaxis()->SetLabelFont(62);
  

  TF1 *f_bg = new TF1("f_bg","[0]+[1]*x+[2]*pow(x,2)+[3]*pow(x,3)+[4]*pow(x,4)+[5]*pow(x,5)+[6]*pow(x,6)",1060,1270.5);
  f_bg->FixParameter(0,6.46759e+01);
  f_bg->FixParameter(1,-7.41685e-02);
  f_bg->FixParameter(2,-5.15207e-05);
  f_bg->FixParameter(3,1.33597e-08);
  f_bg->FixParameter(4,5.12379e-11);
  f_bg->FixParameter(5,3.39359e-14);
  f_bg->FixParameter(6,-3.81709e-17);
  f_bg->SetLineColor(kGreen+3);
  ////// gaus for Lambda peak
  TF1 *f1 = new TF1("f1","gaus",1114.05,1117.19);//1114.05,1117.19
  // f1->SetParameter(0,2.31796e+02);
  // f1->SetParameter(1,1.1563e+03);
  // f1->SetParameter(0,1.14804e+00);
  //  h1->Fit("f1","MR0");


  ////// gaus for Sigma peak
  TF1 *f_s = new TF1("f_s","gaus",1190.6,1194.6);//1114.05,1117.19
  // f1->SetParameter(0,2.31796e+02);
  // f1->SetParameter(1,1.1563e+03);
  // f1->SetParameter(0,1.14804e+00);
  h1->Fit("f_s","MR0");

  TF1 *f2 = new TF1("f2","crystalball(0)+pol6(5)", 1080, 1186);
  // f2->SetParameter(0,f1->GetParameter(0));
  // f2->SetParameter(1,f1->GetParameter(1));
  // f2->SetParameter(2,f1->GetParameter(2));
 
  f2->SetParameter(0,2.26697e+02);
  f2->SetParameter(1,1.11567e+03);
  f2->SetParameter(2,1.20011e+00);

  f2->SetParameter(3, -1.43897e+00);//-1.57816e+00//,-1.43897e+00
  f2->SetParameter(4,5.87249e-01);//3.59386e-01///5.87249e-01

  //// background parameters
  f2->FixParameter(5,6.46759e+01);//6.46759e+01
  f2->FixParameter(6,-7.41685e-02);
  f2->FixParameter(7,-5.15207e-05);
  f2->FixParameter(8,1.33597e-08);
  f2->FixParameter(9,5.12379e-11);
  f2->FixParameter(10,3.39359e-14);
  f2->FixParameter(11,-3.81709e-17);

  //// two crystal ball and a accidental shape
  TF1 *f3 = new TF1("f3","crystalball(0)+pol6(5)+crystalball(12) ", 1067, 1274.5);
  // f3->SetParameter(0,f1->GetParameter(0));
  // f3->SetParameter(1,f1->GetParameter(1));
  // f3->SetParameter(2,f1->GetParameter(2));
 
  f3->FixParameter(0,2.14697e+02);///2.26697e+02
  // f3->SetParLimits(0,2.3397e+02,2.89697e+02);
  f3->SetParameter(1,1.11567e+03);
  // f3->SetParLimits(1,1.11570e+03,1.11572e+03);
  f3->SetParameter(2,1.20011e+00);


  f3->SetParameter(3, -1.43897e+00);//-1.57816e+00//,-1.43897e+00
  f3->SetParameter(4,5.87249e-01);//3.59386e-01///5.87249e-01

  //// background parameters
  f3->FixParameter(5,6.46759e+01);//6.46759e+01
  f3->FixParameter(6,-7.41685e-02);
  f3->FixParameter(7,-5.15207e-05);
  f3->FixParameter(8,1.33597e-08);
  f3->FixParameter(9,5.12379e-11);
  f3->FixParameter(10,3.39359e-14);
  f3->FixParameter(11,-3.81709e-17);

  ///// Sigma parameters (to initialize)
  // f3->FixParameter(12,f_s->GetParameter(0));
  // f3->SetParameter(13,f_s->GetParameter(1));
  // f3->SetParameter(14,f_s->GetParameter(2));

  f3->FixParameter(12,5.772139e+01);
  f3->SetParameter(13,1.19251e+03);
  f3->SetParameter(14,1.27974e+00);

 
  f3->SetParameter(15, -1.43897e+00);//-1.57816e+00//,-1.43897e+00
  f3->SetParameter(16,5.87249e-01);//3.59386e-01///5.87249e-01

  f3->SetLineWidth(1.0);

  TCanvas *c1 = new TCanvas("c1","c1",800,800);
  c1->cd();
  h1->Draw();
  h1_bg->Draw("same");
  h1->Fit("f3","MR");
  f_bg->Draw("same");
  // h1->Fit("f2","MR");

  TLatex l;  //// close these lines to get the fitting parameters
  l.SetTextSize(0.055);
  l.SetTextFont(62);// time bold italic 62 current 02/18/2021
  l.DrawLatex(1126,200,Form("#Lambda"));
  l.DrawLatex(1126,179,Form("#color[2]{Mean = 1115.68 #pm 0.048 MeV}"));
  l.DrawLatex(1126,158,Form("#color[2]{Width #approx 3.15 #pm 0.051 MeV FWHM}"));

  l.DrawLatex(1193,116,Form("#Sigma^{0}"));
  l.DrawLatex(1150,95,Form("#color[2]{Mean = 1192.55 #pm 0.094 MeV}"));// On June 10 2020 to directly write mean and sigma
  l.DrawLatex(1150,74,Form("#color[2]{Width #approx 3.1 #pm 0.09 MeV FWHM}"));

  TLatex l2;  //// close these lines to get the fitting parameters
  l2.SetTextSize(0.06);
  l2.SetTextFont(62);
  l2.DrawLatex(1040,20,Form("Accidentals"));
 
  TLatex l5;  //// close these lines to get the fitting parameters
  l5.SetTextSize(0.07);
  l5.SetTextFont(72);
  l5.DrawLatex(1195,-37.5,Form("c^{2}"));


  
  // TCanvas *c2 = new TCanvas("c2","c2",800,800);
  // c2->cd();
  // hhb->Draw("E2");
  // hhb->SetFillStyle(3002);
  // hhb->SetMarkerStyle(28);
  // hhb->SetMarkerColor(kGreen);
  // //  hhb->Fit("f_bg","","",1060.,1270.);
  // f_bg->Draw("same");
}
