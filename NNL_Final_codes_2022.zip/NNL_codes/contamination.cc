///H contamination curve

//// The fit_function is QF shape with out the Lambda peak
Double_t fit_fun(Double_t *x, Double_t *par) {
  
 
  double A;
  double B;

  A = par[0]+par[1]*x[0]+par[2]*pow(x[0],2)+par[3]*pow(x[0],3)+par[4]*pow(x[0],4);
  
  B= par[5]+par[6]*x[0]+par[7]*pow(x[0],2)+par[8]*pow(x[0],3)+par[9]*pow(x[0],4)+par[10]*pow(x[0],5)+par[11]*pow(x[0],6)+par[12]*pow(x[0],7);

  // B= par[13]*B;  //// par[13]  is the scaling factor just incase it is needed
  if(B<0){B=0;}
    return A+B;
}
///.................................................................................................................................
////=======================================================================

//// function to draw Lambda underneath^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
double L_underneath( double *x, double *par ){//copied from result_2D.C (2020/12/21)

  double invsq2pi = 0.3989422804014;   // (2 pi)^(-1/2)
  double mpshift  = -0.22278298;       // Landau maximum location
  double np = 500.0;      // number of convolution steps
  double sc =   5.0;      // convolution extends to +-sc Gaussian sigmas
  double xx, mpc, fland, sum = 0.0, xlow,xupp, step, i;
  double val1, val2;

  // MP shift correction
  mpc = par[1] - mpshift * par[0];
  // Range of convolution integral
  xlow = x[0] - sc * par[3];
  xupp = x[0] + sc * par[3];
  step = (xupp-xlow) / np;
  // Convolution integral of Landau and Gaussian by sum
  for(i=1.0; i<=np/2; i++) {
	xx = xlow + (i-.5) * step*par[1]; //// BP added *par[1] on OCT 23, 2021;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);

	xx = xupp - (i-.5) * step;
	fland = TMath::Landau(xx,mpc,par[0]) / par[0];
	sum += fland * TMath::Gaus(x[0],xx,par[3]);
  }
  val1 = step * sum * invsq2pi / par[3];

  double C2 =  par[2]*val1;  //// up to here is the Lambda  

 
  return C2;
 
}/// end 

//// up to here is function to draw Lambda underneath^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

void contamination()
{
 
  TFile *t1 = new TFile("./root/H_HT_HC_OCT23_2021_1.root");
  
  
  TH1F *h_22 = (TH1F*)t1->Get("h_hc0");
  TH1F *h2_b = (TH1F*)t1->Get("h_hc0b");
  h2_b->SetMarkerColor(kGreen+3);

  TH1F *h_1 = (TH1F*)t1->Get("h_2_a");
  h_1->SetLineColor(kMagenta);
  
  gStyle->SetOptStat(0);
  gStyle->SetOptFit(1111111);
  
  // gStyle->SetStatFont(62);
  // gStyle->SetStatFontSize(0.05);
  // gStyle->SetStatTextColor(2);
  
  gStyle->SetPadRightMargin(0.008);
  gStyle->SetPadLeftMargin(0.115);
  gStyle->SetPadTopMargin(0.03);
  gStyle->SetPadBottomMargin(0.17);

  h_22->GetXaxis()->SetTitle("-B_{#Lambda} (MeV)"); // Tritium target for H kinematics
  h_22->GetXaxis()->SetTitleSize(0.075);
  h_22->GetXaxis()->SetTitleFont(62);//  32 gives the times italic bold
  h_22->GetXaxis()->SetTitleOffset(1.05);  
  h_22->GetXaxis()->CenterTitle();
  h_22->GetXaxis()->SetLabelSize(0.07);
  h_22->GetXaxis()->SetLabelFont(62); // 22 for times bold
  
  h_22->GetYaxis()->SetTitle("Counts / 1.5 MeV");
  h_22->GetYaxis()->CenterTitle();
  h_22->GetYaxis()->SetTitleSize(0.075);
  h_22->GetYaxis()->SetTitleFont(62);//  32 gives the times italic bold  // 22 gives times bold
  h_22->GetYaxis()->SetTitleOffset(0.75);
  h_22->GetYaxis()->SetLabelSize(0.07);
  h_22->GetYaxis()->SetLabelFont(62); // for times bold


  
  
  TF1 *f_bg = new TF1("f_bg","[0]+[1]*x+[2]*pow(x,2)+[3]*pow(x,3)+[4]*pow(x,4)",-90.0,90.0);
  f_bg->SetParameter(0,7.31722e+00);
  f_bg->SetParameter(1,-3.49895e-02);
  f_bg->SetParameter(2,-8.46330e-04);
  f_bg->SetParameter(3,1.66854e-06);
  f_bg->SetParameter(4,2.36786e-08);
  f_bg->SetLineColor(kMagenta);
  f_bg->SetLineStyle(2);

  TF1 *f_bg1 = new TF1("f_bg1","[0]+[1]*x+[2]*pow(x,2)+[3]*pow(x,3)+[4]*pow(x,4)",-90.0,-40.8);
  f_bg1->SetParameter(0,7.31722e+00);
  f_bg1->SetParameter(1,-3.49895e-02);
  f_bg1->SetParameter(2,-8.46330e-04);
  f_bg1->SetParameter(3,1.66854e-06);
  f_bg1->SetParameter(4,2.36786e-08);
 
  ///with out bg initially
  TF1 *f_qf = new TF1("f_qf","[0]+[1]*x+[2]*pow(x,2)+[3]*pow(x,3)+[4]*pow(x,4)+[5]*pow(x,5)+[6]*pow(x,6)+[7]*pow(x,7)",-41.0,81.5);
  f_qf->SetParameter(0,5.01368e+01);
  f_qf->SetParameter(1,3.92288e-01);
  f_qf->SetParameter(2,-4.26013e-02);
  f_qf->SetParameter(3,-2.07898e-04);
  f_qf->SetParameter(4,1.88870e-05);
  
  f_qf->SetParameter(5,-3.70679e-09);
  f_qf->SetParameter(6,-3.82194e-09);
  f_qf->SetParameter(7,2.57232e-11);
  f_qf->SetNpx(10000);
  
  
  
  //TF1 *f_qf_bg = new TF1("f_qf_bg","f_bg +[5]+[6]*x+[7]*pow(x,2)+[8]*pow(x,3)+[9]*pow(x,4)+[10]*pow(x,5)+[11]*pow(x,6)+[12]*pow(x,7)",-81.0,81.5);/////-41.0,81.5) original range
  //// This function doesnot include the Lambda peak
  TF1 *f_qf_bg = new TF1("f_qf_bg",fit_fun,-11.0,81.5,13);/////-41.0,81.5) original range  

  //// parameters from background
  f_qf_bg->FixParameter(0,7.31722e+00);
  f_qf_bg->FixParameter(1,-3.49895e-02);
  f_qf_bg->FixParameter(2,-8.46330e-04);
  f_qf_bg->FixParameter(3,1.66854e-06);
  f_qf_bg->FixParameter(4,2.36786e-08);  

  ///parameters from Lnn QF (H kinematics)
  f_qf_bg->FixParameter(5,3.94629e+01);//3.90629e+01
  f_qf_bg->FixParameter(6,3.72026e-01);//3.75239e-01
  f_qf_bg->FixParameter(7,-3.39315e-02);//-3.55636e-02
  f_qf_bg->FixParameter(8,-1.72631e-04);///
  f_qf_bg->FixParameter(9,1.35255e-05);//1.43105e-05
  
  f_qf_bg->FixParameter(10,1.19324e-08);//1.10703e-09
  f_qf_bg->FixParameter(11,-2.69972e-09);//-2.72618e-09)
  f_qf_bg->FixParameter(12,1.67582e-11); //1.73981e-11
  
  
  f_qf_bg->SetLineStyle(2);
  f_qf_bg->SetNpx(100);

  /////////////////// Finally the Lambda peak is included in the QF function-----------------------------------------------------
  TF1 *fun = new TF1("fun","crystalball(0)+pol4(5)+pol4(10)+pol7(15)",-40.6,80.2); /// Lambda fit range -25,55 MeV
  // fun->SetParameter(0,8.32361e+01);  /// first 3 are gaussian parameters
  // fun->SetParameter(1,-8.10308e-02);
  // fun->SetParameter(2,1.36619e+00);
  // fun->SetParameter(3,-1.57682e+00);
  // fun->SetParameter(4,7.59348e-01);
  // fun->0(FixParameterSet,fun->GetParameter(0)*0.25);

  fun->FixParameter(0,8.31287e+01);  /// first 3 are gaussian parameters
  fun->FixParameter(1,-7.71375e-02);
  fun->FixParameter(2,1.37022);
  fun->FixParameter(3,-1.61429);
  fun->FixParameter(4,7.13949e-01);

  fun->FixParameter(0,fun->GetParameter(0)*0.30);

  ////// accidental in Lambda Missing Mass
  fun->FixParameter(5,0.206486);///2.63606e-01//0.266486
  fun->FixParameter(6,-0.00171973);
  fun->FixParameter(7,-3.24495e-05);
  fun->FixParameter(8,1.47153e-07);//1.47153e-07
  fun->FixParameter(9,6.88e-10);
 
  //// parameters from background Lnn (H kinematics)
  fun->FixParameter(10,7.31722e+00);
  fun->FixParameter(11,-3.49895e-02);
  fun->FixParameter(12,-8.46330e-04);
  fun->FixParameter(13,1.66854e-06);
  fun->FixParameter(14,2.36786e-08);  

  ///parameters from Lnn QF (H kinematics)
  // fun->SetParameter(15,4.05965e+01);
  // fun->SetParameter(16,4.11792e-01);
  // fun->SetParameter(17,-3.64739e-02);
  // fun->SetParameter(18,-2.06666e-04);
  // fun->SetParameter(19,1.53680e-05);
  
  // fun->SetParameter(20,1.31906e-08);
  // fun->SetParameter(21,-3.13918e-09);
  // fun->SetParameter(22,1.98513e-11); 

  ///parameters from Lnn QF (H kinematics)
  fun->SetParameter(15,3.90629e+01);///3.90629e+01
  fun->SetParameter(16,3.72026e-01);//3.72026e-01
  fun->SetParameter(17,-3.39315e-02);//-3.39315e-02
  fun->SetParameter(18,-1.72631e-04);//-1.72631e-04
  fun->SetParameter(19,1.35255e-05);//1.35255e-05
  
  fun->SetParameter(20,1.19324e-08);//1.19324e-08
  fun->SetParameter(21,-2.69972e-09);//-2.69972e-09
  fun->SetParameter(22,1.67582e-11); //1.67582e-11
  fun->SetNpx(1000);
  fun->SetLineWidth(2);
  
  /////^^^^^^^^^^^^ to draw the Lambda underneath^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   TF1 *f_under = new TF1("f_under","crystalball(0)+pol4(5)",-30,50.0);
  f_under->FixParameter(0,8.31287e+01);  /// first 3 are gaussian parameters
  f_under->FixParameter(1,-7.71375e-02);
  f_under->FixParameter(2,1.37022);
  f_under->FixParameter(3,-1.61429);
  f_under->FixParameter(4,7.13949e-01);
  
  f_under->FixParameter(0,f_under->GetParameter(0)*0.3);

  ////// Parameters from the background
  f_under->FixParameter(5,0.266486);///2.63606e-01
  f_under->FixParameter(6,-0.00171973);
  f_under->FixParameter(7,-3.24495e-05);
  f_under->FixParameter(8,1.47153e-07);//1.47153e-07
  f_under->FixParameter(9,6.88e-10);

  f_under->SetLineColor(kBlue);
  f_under->SetLineStyle(2);
  f_under->SetNpx(100);

  TCanvas *c2 = new TCanvas("c2","c2",600,600);
  c2->SetCanvasSize(1250, 800);
  c2->cd();
  h_22->Draw();
  h2_b->Draw("same");
  f_bg->Draw("same");
  f_bg1->Draw("same");

  // h_1->Draw("same");
  //  h2->Fit("f_qf_bg","","",-41.0,81.5);
  //h2->Fit("f_qf","","",-41.0,81.5);
  f_qf_bg->Draw("same");/// Lnn Qf shape

  // h_22->Fit("fun","MR+");
  fun->Draw("same");
  f_under->Draw("same");

  TLatex l11;
  l11.SetTextSize(0.075);
  l11.SetTextFont(62);
  l11.DrawLatex(25.,60,Form("I. Accidentals"));
  l11.DrawLatex(25.0,70.,Form("II. #Lambda quasifree"));
  l11.DrawLatex(25.0,80.,Form("III. #Sigma quasifree"));

  l11.DrawLatex(12.,8,Form("I"));
  l11.DrawLatex(20.,45,Form("II"));
  l11.DrawLatex(55.,16,Form("III"));

  TLatex l12;
  l12.SetTextSize(0.082);
  l12.SetTextFont(62);
  l12.DrawLatex(-11.,19.,Form("#color[4]{#Lambda}"));
  l12.DrawLatex(-11.5,70.,Form("#Lambda"));

}
