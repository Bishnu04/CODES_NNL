// October 3, 2021
// To study about the Free Lambda peak
// anayzing the H/T dada as tritium mass and Lnn as a recoil
void HE_QF_OCT14()
{
  gStyle->SetOptStat(11111);
  gStyle->SetOptFit(1111111);

  gStyle->SetStatFont(62);
  gStyle->SetStatFontSize(0.05);
  gStyle->SetStatTextColor(2);
  
  gStyle->SetPadRightMargin(0.08);
  gStyle->SetPadLeftMargin(0.14);
  gStyle->SetPadTopMargin(0.04);
  gStyle->SetPadBottomMargin(0.165);
  
  TFile *t3 = new TFile("./root/SIMA_3He_contamination_OCT_11.root"); 
  TH1F *h3 = (TH1F*)t3->Get("h1"); ///C/1.5 MeV
  

  TF1 *f2 = new TF1("f2","gaus(0)+[3]+[4]*x+[5]*pow(x,2)+[6]*pow(x,3)+[7]*pow(x,4)+[8]*pow(x,5)+[9]*pow(x,6)",3.,154.);  
  /*
  ///// obtained by fitting a Gaussian in the central region of the peak
  f2->SetParameter(0,3.06460e+03);
  f2->SetParameter(1,5.80669e+01);
  f2->SetParameter(2,1.59486e+01);
  
  /// Sixthe order updated obtained by fittinh a sixth polynomial in the while range
  f2->SetParameter(3,2.65297e+03);
  f2->SetParameter(4,-5.49030e+02);
  f2->SetParameter(5,4.79824e+01);
  f2->SetParameter(6,-9.67654e-01);
  f2->SetParameter(7,8.34479e-03);
  f2->SetParameter(8,-3.36642e-05);
  f2->SetParameter(9,5.25357e-08);
  f2->SetNpx(1000);
*/
  /////// fitted parameters
  f2->FixParameter(0,1.34700e+04);
  f2->FixParameter(1,5.16891e+01);
  f2->FixParameter(2,2.37999e+01);
  
  /// Sixthe order updated obtained by fittinh a sixth polynomial in the while range
  f2->FixParameter(3,-1.15972e+03);
  f2->FixParameter(4,-1.40280e+02);
  f2->FixParameter(5,7.55137e+00);
  f2->FixParameter(6,2.32356e-02);
  f2->FixParameter(7,-1.86532e-03);
  f2->FixParameter(8,1.45534e-05);
  f2->FixParameter(9,-3.39134e-08);
  f2->SetNpx(1000);

  
  
  TCanvas *c2 = new TCanvas("c2","c2",600,600);
  c2->cd();
  h3->Draw();  
  h3->Fit("f2","MR+");

  TLatex l3;
  l3.SetTextSize(0.04);  
  l3.DrawLatex(-80,18000, Form("^{3}He contamination (SIM A)"));


  TF1 *f3 = new TF1("f3","0.000096*(gaus(0)+[3]+[4]*x+[5]*pow(x,2)+[6]*pow(x,3)+[7]*pow(x,4)+[8]*pow(x,5)+[9]*pow(x,6))",3.,154.);// 0.000096*
  f3->FixParameter(0,1.34700e+04);
  f3->FixParameter(1,5.16891e+01);
  f3->FixParameter(2,2.37999e+01);
  
  /// Sixthe order updated obtained by fittinh a sixth polynomial in the while range
  f3->FixParameter(3,-1.15972e+03);
  f3->FixParameter(4,-1.40280e+02);
  f3->FixParameter(5,7.55137e+00);
  f3->FixParameter(6,2.32356e-02);
  f3->FixParameter(7,-1.86532e-03);
  f3->FixParameter(8,1.45534e-05);
  f3->FixParameter(9,-3.39134e-08);
  f3->SetNpx(1000);


  TCanvas *c3 = new TCanvas("c3","c3",600,600);
  c3->cd();
  f3->Draw();
  /*
  double pp[10];// par from 60 to 75
  f3->GetParameters(pp);
  for(int i=0;i<10;i++){
    pp[i] = pp[i]*0.000096;
  }

  TF1 *f4 = new TF1("f4","gaus(0)+[3]+[4]*x+[5]*pow(x,2)+[6]*pow(x,3)+[7]*pow(x,4)+[8]*pow(x,5)+[9]*pow(x,6)",3.,154.);
  f4->FixParameter(0,pp[0]);
  f4->FixParameter(1,pp[1]);
  f4->FixParameter(2,pp[2]);
  f4->FixParameter(3,pp[3]);
  f4->FixParameter(4,pp[4]);
  f4->FixParameter(5,pp[5]);
  f4->FixParameter(6,pp[6]);
  f4->FixParameter(7,pp[7]); 

  f4->FixParameter(8,pp[8]);
  f4->FixParameter(9,pp[9]);
  
  TCanvas *c4 = new TCanvas("c4","c4",600,600);
  c4->cd();
  f4->Draw();


  TF1 *f5 = new TF1("f5","(gaus(0)+[3]+[4]*x+[5]*pow(x,2)+[6]*pow(x,3)+[7]*pow(x,4)+[8]*pow(x,5)+[9]*pow(x,6))",3.,154.);// 0.000096*
  f5->FixParameter(0,1.29312);//1.34700e+04
  f5->FixParameter(1,0.0049621536);//5.16891e+01
  f5->FixParameter(2,0.0022847904);//2.37999e+01
  
  /// Sixthe order updated obtained by fittinh a sixth polynomial in the while range
  f5->FixParameter(3,-0.11133312);//-1.15972e+03
  f5->FixParameter(4,-0.01346688);//1.40280e+02
  f5->FixParameter(5,0.0007249315);//7.55137e+00
  f5->FixParameter(6,0.0002230618e-02);//2.32356e-02
  f5->FixParameter(7,-0.0001790707e-03);//-1.86532e-03
  f5->FixParameter(8,0.0001397126e-05);//1.45534e-05
  f5->FixParameter(9,-0.0003255686e-08);//-3.39134
  f5->SetNpx(1000);
  
  TCanvas *c5 = new TCanvas("c5","c5",600,600);
  c5->cd();
  f5->Draw();

  */
  
 
}

